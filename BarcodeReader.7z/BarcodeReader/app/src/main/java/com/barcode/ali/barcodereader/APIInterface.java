package com.barcode.ali.barcodereader;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

interface APIInterface {

    @GET("/barcode")
    Call<Void> doSendBarcodes(@Query("barcode") String barcode);

}